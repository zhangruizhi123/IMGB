#ifndef NASM_VERSION_H
#define NASM_VERSION_H
#define NASM_MAJOR_VER      2
#define NASM_MINOR_VER      5
#define NASM_SUBMINOR_VER   99
#define NASM_PATCHLEVEL_VER 98
#define NASM_VERSION_ID     0x02056362
#define NASM_VER            "2.06rc8"
#endif /* NASM_VERSION_H */
